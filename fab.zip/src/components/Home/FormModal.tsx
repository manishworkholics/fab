const FormModal = () => {
  return (
    <iframe 
      // width="540" 
      // height="305" 
      width="100%" 
      height="100%" 
      src="https://sibforms.com/serve/MUIFAKmQDj3BA_yAfZ2JjG1YN03_Yf_bntLoTTvE9yOu90iB5SncK-t7DIDsfi3d2JaWWaYAHJR39ZTEJIdyZ2K0tXi91akiNtl44QPz8lhp3ofZqb_3hlOljyfGqY3aYCBnSa-3u_FjIPpyooj0MJzm5GGdp2R5Bbc68-zFjWlnaw4iEwEBtt0z9mXHo06EohTfw1nRZCFQ9W3e" 
      // frameborder="0" 
      scrolling="auto" 
      // allowfullscreen 
      // style="display: block;margin-left: auto;margin-right: auto;max-width: 100%;"
      // className='block mx-auto max-w-[100%] h-full'
      // className="w-full h-full border-0 overflow-y-scroll scrollbar-hide"
      // style={{ 
      //   display: 'block', 
      //   marginLeft: 'auto', 
      //   marginRight: 'auto', 
      //   maxWidth: '100%', 
      //   height: '100%' 
      // }}
    />
  );
};

export default FormModal