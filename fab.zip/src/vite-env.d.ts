/// <reference types="vite/client" />

interface ImportMeta {
  readonly env: ImportMetaEnv
}