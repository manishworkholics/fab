import EMSPageView from "@/components/EMS/EMSPageView";

export default function EMSView() {
  return <EMSPageView />;
}
