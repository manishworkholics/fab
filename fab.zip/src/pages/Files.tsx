import FilesView from "@/components/Files/FilesView";

const Files = () => {
  return <FilesView />;
};

export default Files;
