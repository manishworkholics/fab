// import SingleEMSQuote from "@/components/Quote/SingleEMSQuote";

// export default function EmsSingleQuoteView() {
//   return <SingleEMSQuote />;
import EMSSingleQuotePage from "@/components/Quote/EMSSingleQuotePage";

export default function EmsSingleQuoteView() {
  return <EMSSingleQuotePage />;
}
