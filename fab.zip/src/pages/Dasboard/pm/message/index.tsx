import Chat from "@/components/Message/Chat";

const Messages = () => {
  return <Chat />;
};

export default Messages;
